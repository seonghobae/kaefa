


#####################################################
# S3 method DescribeBy
DescribeBy <- function (object, ...) {
  UseMethod("DescribeBy")
}
#####################################################
