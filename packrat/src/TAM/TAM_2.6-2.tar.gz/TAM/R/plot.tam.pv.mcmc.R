
plot.tam.pv.mcmc <- function(x, ...)
{
	plot( x$parameter_samples, ... )
}