
tam.jml2 <- function(...){
	.Defunct(new="tam.jml", package="TAM")
}
