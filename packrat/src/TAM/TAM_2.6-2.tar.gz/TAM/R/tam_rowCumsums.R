
tam_rowCumsums <- function(matr){ 
	rowCumsums2_source(matr)
}

rowCumsums.TAM <- tam_rowCumsums