library(testthat)
library(lavaan.survey)

test_check("lavaan.survey")
