
pow <- function(x , a)
{
	return( x^a )
}
