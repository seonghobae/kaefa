rasch.conquest <- function(...){
	.Defunct(new="R2conquest", package="sirt")
}
