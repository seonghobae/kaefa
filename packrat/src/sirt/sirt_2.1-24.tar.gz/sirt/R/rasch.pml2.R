rasch.pml2 <- function(...){
	.Defunct(new="rasch.pml3", package="sirt")
}
