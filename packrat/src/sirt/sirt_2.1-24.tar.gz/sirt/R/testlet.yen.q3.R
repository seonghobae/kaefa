testlet.yen.q3 <- function(...){
	.Defunct(new="Q3.testlet", package="sirt")
}
