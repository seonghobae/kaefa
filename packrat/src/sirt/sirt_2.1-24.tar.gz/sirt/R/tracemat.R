
########################################
# trace of a matrix
tracemat <- function(A)
{ 
    res <- sum( diag(A) ) 
	return(res)
} 
########################################
