yen.q3 <- function(...){
	.Defunct(new="Q3", package="sirt")
}
