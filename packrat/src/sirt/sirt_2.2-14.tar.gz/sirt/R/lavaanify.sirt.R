## File Name: lavaanify.sirt.R
## File Version: 1.12
## File Last Change: 2017-01-18 11:02:47

lavaanify.sirt <- TAM::lavaanify.IRT
