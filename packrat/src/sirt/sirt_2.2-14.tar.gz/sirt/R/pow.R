## File Name: pow.R
## File Version: 0.02
## File Last Change: 2017-01-18 11:02:51

pow <- function(x , a)
{
	return( x^a )
}
