## File Name: rasch.conquest.R
## File Version: 1.32
## File Last Change: 2017-01-18 11:02:52
rasch.conquest <- function(...){
	.Defunct(new="R2conquest", package="sirt")
}
