## File Name: rasch.evm.pcm.methods.R
## File Version: 0.03
## File Last Change: 2017-01-18 11:02:52

#*****************************************************************

#***********************
# variance matrix
vcov.rasch.evm.pcm <- function( object , ... ){
     return( object$vcov)
				}
				
#************************				
# coefficients
coef.rasch.evm.pcm <- function( object , ... ){
     return( object$coef )
				}				
								
#*****************************************************************				
