## File Name: rasch.pml2.R
## File Version: 4.13
## File Last Change: 2017-01-18 11:02:53
rasch.pml2 <- function(...){
	.Defunct(new="rasch.pml3", package="sirt")
}
