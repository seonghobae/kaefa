## File Name: sirt_csink.R
## File Version: 0.01
## File Last Change: 2017-09-20 10:38:41

sirt_csink <- function(file)
{
   CDM::csink( file = file )
}
