## File Name: sum0.R
## File Version: 0.01
## File Last Change: 2017-08-21 18:25:43

sum0 <- function(x)
{
	sum(x, na.rm=TRUE)
}
