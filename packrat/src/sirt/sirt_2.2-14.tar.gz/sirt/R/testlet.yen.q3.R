## File Name: testlet.yen.q3.R
## File Version: 2.02
## File Last Change: 2017-01-18 11:02:55
testlet.yen.q3 <- function(...){
	.Defunct(new="Q3.testlet", package="sirt")
}
